<?php
session_start();
require_once __DIR__ . '/config.php';
$config = require __DIR__ . '/config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pass = $_POST['password'] ?? '';
    if (hash_equals($config['dashboard_password'], $pass)) {
        $_SESSION['dashboard_auth'] = true;
        header('Location: index.php');
        exit;
    }
    $error = 'Invalid password';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login — Pay Dashboard</title>
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{--bg:#0a0c10;--card:#111318;--border:#1e2330;--accent:#4f6ef7;--text:#e2e8f0;--muted:#64748b;--danger:#ef4444}
body{font-family:'Sora',sans-serif;background:var(--bg);color:var(--text);min-height:100vh;display:flex;align-items:center;justify-content:center;background-image:radial-gradient(ellipse 80% 50% at 50% -20%,rgba(79,110,247,.15),transparent)}
.card{background:var(--card);border:1px solid var(--border);border-radius:20px;padding:40px;width:100%;max-width:380px;box-shadow:0 25px 60px rgba(0,0,0,.5)}
.logo{text-align:center;margin-bottom:32px}
.logo-icon{width:52px;height:52px;background:linear-gradient(135deg,#4f6ef7,#7c3aed);border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:22px;margin:0 auto 12px}
.logo h1{font-size:18px;font-weight:600}
.logo p{font-size:12px;color:var(--muted);margin-top:4px}
label{display:block;font-size:12px;font-weight:500;color:var(--muted);margin-bottom:6px;letter-spacing:.04em;text-transform:uppercase}
input[type=password]{width:100%;padding:12px 14px;background:#0a0c10;border:1px solid var(--border);border-radius:10px;color:var(--text);font-family:'JetBrains Mono',monospace;font-size:14px;outline:none;transition:border .2s}
input[type=password]:focus{border-color:var(--accent)}
.error{background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.2);color:#fca5a5;padding:10px 14px;border-radius:8px;font-size:13px;margin-bottom:16px}
button{width:100%;margin-top:18px;padding:13px;background:linear-gradient(135deg,#4f6ef7,#7c3aed);color:#fff;border:none;border-radius:10px;font-family:'Sora',sans-serif;font-size:14px;font-weight:600;cursor:pointer;transition:all .2s}
button:hover{transform:translateY(-1px);box-shadow:0 8px 25px rgba(79,110,247,.4)}
</style>
</head>
<body>
<div class="card">
  <div class="logo">
    <div class="logo-icon">💳</div>
    <h1>Pay Dashboard</h1>
    <p>pay.rudhvedinfotech.com</p>
  </div>
  <?php if (!empty($error)): ?>
  <div class="error"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>
  <form method="POST">
    <label>Password</label>
    <input type="password" name="password" autofocus placeholder="Enter dashboard password">
    <button type="submit">Sign In →</button>
  </form>
</div>
</body>
</html>
