<?php
/**
 * Helper functions for the Payment Gateway Aggregator
 */

$config = require __DIR__ . '/../config.php';

// ─── Transaction JSON Storage ─────────────────────────────────────────────────

function txn_path(string $txn_id): string {
    global $config;
    return $config['data_dir'] . '/' . $txn_id . '.json';
}

function txn_save(array $data): bool {
    $path = txn_path($data['txn_id']);
    $data['updated_at'] = date('c');
    return file_put_contents($path, json_encode($data, JSON_PRETTY_PRINT)) !== false;
}

function txn_load(string $txn_id): ?array {
    $path = txn_path($txn_id);
    if (!file_exists($path)) return null;
    return json_decode(file_get_contents($path), true);
}

function txn_list(): array {
    global $config;
    $files = glob($config['data_dir'] . '/TXN_*.json');
    $txns  = [];
    foreach ($files as $f) {
        $d = json_decode(file_get_contents($f), true);
        if ($d) $txns[] = $d;
    }
    usort($txns, fn($a, $b) => strtotime($b['created_at']) - strtotime($a['created_at']));
    return $txns;
}

function txn_update(string $txn_id, array $fields): bool {
    $data = txn_load($txn_id);
    if (!$data) return false;
    $data = array_merge($data, $fields);
    return txn_save($data);
}

// ─── ID Generation ────────────────────────────────────────────────────────────

function generate_txn_id(): string {
    return 'TXN_' . strtoupper(bin2hex(random_bytes(6))) . '_' . time();
}

// ─── API Auth Middleware ──────────────────────────────────────────────────────

function require_api_auth(): void {
    global $config;
    $headers = getallheaders();
    $key = $headers['X-Api-Key'] ?? $headers['x-api-key'] ?? ($_SERVER['HTTP_X_API_KEY'] ?? '');
    if (empty($key) || !hash_equals($config['api_key'], $key)) {
        http_response_code(401);
        echo json_encode(['success' => false, 'error' => 'Unauthorized: invalid or missing X-Api-Key header']);
        exit;
    }
}

// ─── JSON Response Helpers ────────────────────────────────────────────────────

function json_response(array $data, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

function json_error(string $msg, int $code = 400): void {
    json_response(['success' => false, 'error' => $msg], $code);
}

// ─── HTTP Client (no cURL dependency — uses PHP streams) ─────────────────────

function http_post(string $url, array $data, array $headers = [], bool $basic_auth = false, string $user = '', string $pass = ''): array {
    $payload = json_encode($data);
    $h = ["Content-Type: application/json", "Content-Length: " . strlen($payload)];
    $h = array_merge($h, $headers);

    $opts = [
        'http' => [
            'method'  => 'POST',
            'header'  => implode("\r\n", $h),
            'content' => $payload,
            'ignore_errors' => true,
        ]
    ];

    if ($basic_auth) {
        $opts['http']['header'] .= "\r\nAuthorization: Basic " . base64_encode("$user:$pass");
    }

    $ctx  = stream_context_create($opts);
    $body = @file_get_contents($url, false, $ctx);
    $meta = $http_response_header ?? [];
    $code = 0;
    foreach ($meta as $line) {
        if (preg_match('/HTTP\/\d\.\d (\d+)/', $line, $m)) {
            $code = (int)$m[1];
        }
    }

    return [
        'status' => $code,
        'body'   => $body,
        'data'   => json_decode($body, true),
    ];
}

function http_get(string $url, array $headers = []): array {
    $h = ["Content-Type: application/json"];
    $h = array_merge($h, $headers);

    $opts = [
        'http' => [
            'method'  => 'GET',
            'header'  => implode("\r\n", $h),
            'ignore_errors' => true,
        ]
    ];

    $ctx  = stream_context_create($opts);
    $body = @file_get_contents($url, false, $ctx);
    $meta = $http_response_header ?? [];
    $code = 0;
    foreach ($meta as $line) {
        if (preg_match('/HTTP\/\d\.\d (\d+)/', $line, $m)) {
            $code = (int)$m[1];
        }
    }

    return [
        'status' => $code,
        'body'   => $body,
        'data'   => json_decode($body, true),
    ];
}

// ─── Notify vara567.com webhook ───────────────────────────────────────────────

function notify_webhook(array $txn): void {
    if (empty($txn['webhook_url'])) return;

    $payload = [
        'event'        => 'payment.' . $txn['status'],
        'txn_id'       => $txn['txn_id'],
        'order_id'     => $txn['order_id'],
        'gateway'      => $txn['gateway'],
        'amount'       => $txn['amount'],
        'currency'     => $txn['currency'],
        'status'       => $txn['status'],
        'gateway_txn'  => $txn['gateway_txn_id'] ?? null,
        'gateway_order'=> $txn['gateway_order_id'] ?? null,
        'paid_at'      => $txn['paid_at'] ?? null,
        'customer'     => [
            'name'  => $txn['customer_name'],
            'email' => $txn['customer_email'],
            'phone' => $txn['customer_phone'],
        ],
        'raw_response' => $txn['gateway_response'] ?? null,
    ];

    // Sign the webhook payload
    global $config;
    $signature = hash_hmac('sha256', json_encode($payload), $config['api_key']);

    http_post($txn['webhook_url'], $payload, [
        'X-Webhook-Signature: ' . $signature,
        'X-Source: pay.rudhvedinfotech.com',
    ]);
}

// ─── Log errors ───────────────────────────────────────────────────────────────

function log_error(string $msg): void {
    global $config;
    $log = $config['data_dir'] . '/error.log';
    file_put_contents($log, date('c') . ' ' . $msg . PHP_EOL, FILE_APPEND);
}
