<?php
/**
 * /return.php  — handles redirect back from Razorpay (POST) or Cashfree (GET/POST)
 *
 * Razorpay POST params: razorpay_payment_id, razorpay_order_id, razorpay_signature
 * Cashfree GET params:  txn, order_id
 */

require_once __DIR__ . '/lib/helpers.php';
require_once __DIR__ . '/lib/Razorpay.php';
require_once __DIR__ . '/lib/Cashfree.php';

$txn_id = trim($_GET['txn'] ?? $_POST['txn'] ?? '');

if (empty($txn_id)) {
    die('Missing transaction ID.');
}

$txn = txn_load($txn_id);
if (!$txn) {
    die('Transaction not found.');
}

// Already processed — just redirect
if (in_array($txn['status'], ['paid', 'failed'])) {
    $redirect_status = $txn['status'];
    goto do_redirect;
}

$gateway = $txn['gateway'];
$status  = 'failed';
$gateway_txn_id = null;
$gateway_response = [];

try {
    if ($gateway === 'razorpay') {
        $rp = new Razorpay($config['razorpay']['key_id'], $config['razorpay']['key_secret']);

        $payment_id  = $_POST['razorpay_payment_id']  ?? '';
        $order_id    = $_POST['razorpay_order_id']    ?? $txn['gateway_order_id'];
        $signature   = $_POST['razorpay_signature']   ?? '';

        if ($payment_id && $signature) {
            $valid = $rp->verifySignature($order_id, $payment_id, $signature);

            if ($valid) {
                $payment_details = $rp->fetchPayment($payment_id);
                $status          = ($payment_details['status'] === 'captured' || $payment_details['status'] === 'authorized') ? 'paid' : 'failed';
                $gateway_txn_id  = $payment_id;
                $gateway_response = $payment_details;
            } else {
                $status = 'failed';
                $gateway_response = ['error' => 'Invalid signature'];
            }
        } else {
            $status = 'failed';
            $gateway_response = ['error' => 'Missing payment_id or signature'];
        }

    } elseif ($gateway === 'cashfree') {
        $cf = new Cashfree($config['cashfree']['app_id'], $config['cashfree']['secret_key'], $config['cashfree']['base_url']);

        $cf_order_id = $_GET['order_id'] ?? $txn['gateway_order_id'];
        $order_status = $cf->getOrderStatus($cf_order_id);
        $gateway_response = $order_status;

        $cf_status = strtoupper($order_status['order_status'] ?? '');

        if ($cf_status === 'PAID') {
            $status = 'paid';
            // Fetch payment details
            $payments = $cf->getOrderPayments($cf_order_id);
            if (!empty($payments[0])) {
                $gateway_txn_id = $payments[0]['cf_payment_id'] ?? null;
                $gateway_response = array_merge($gateway_response, ['payments' => $payments]);
            }
        } elseif (in_array($cf_status, ['EXPIRED', 'CANCELLED', 'FAILED'])) {
            $status = 'failed';
        } else {
            $status = 'pending';
        }
    }

} catch (Exception $e) {
    log_error('[return] ' . $e->getMessage() . ' | txn: ' . $txn_id);
    $status = 'failed';
    $gateway_response = ['exception' => $e->getMessage()];
}

// ── Update Transaction ────────────────────────────────────────────────────────
$update = [
    'status'           => $status,
    'gateway_txn_id'   => $gateway_txn_id,
    'gateway_response' => $gateway_response,
];
if ($status === 'paid') {
    $update['paid_at'] = date('c');
}

txn_update($txn_id, $update);
$txn = array_merge($txn, $update);

// ── Notify vara567.com ────────────────────────────────────────────────────────
notify_webhook($txn);

$redirect_status = $status;

do_redirect:
// Redirect back to vara567.com with status
$return_url = $txn['return_url'];
$separator  = strpos($return_url, '?') !== false ? '&' : '?';
$final_url  = $return_url
    . $separator
    . http_build_query([
        'txn_id'   => $txn_id,
        'order_id' => $txn['order_id'],
        'status'   => $redirect_status,
        'gateway'  => $txn['gateway'],
        'amount'   => $txn['amount'],
    ]);

header('Location: ' . $final_url);
exit;
