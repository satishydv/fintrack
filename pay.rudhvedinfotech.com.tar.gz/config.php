<?php
/**
 * Payment Gateway Aggregator - Configuration
 * Hosted at: https://pay.rudhvedinfotech.com
 * Integrates with: https://vara567.com (Laravel)
 */

return [

    // ─── Shared secret between vara567.com and this project ───────────────────
    // Set the SAME key in vara567.com's .env as PAYMENT_API_KEY
    'api_key' => '12345678',

    // ─── Dashboard Login ──────────────────────────────────────────────────────
    'dashboard_password' => '12345678',

    // ─── This server's base URL ───────────────────────────────────────────────
    'pay_url' => 'https://pay.rudhvedinfotech.com',

    // ─── Razorpay (Live) ──────────────────────────────────────────────────────
    'razorpay' => [
        'key_id'     => 'rzp_live_SXQdFqjif1WauO',
        'key_secret' => 'CRy5rDiXhNC0xEVNCJWOkH5Q',
    ],

    // ─── Cashfree (Production) ───────────────────────────────────────────────
    'cashfree' => [
        'app_id'     => '10159230df4d7622b1ade77e3b03295101',
        'secret_key' => 'cfsk_ma_prod_01e1b074790b8767b6a217cbfe8a46e3_e31de6e8',
        'base_url'   => 'https://api.cashfree.com/pg',  // production
        // sandbox: 'https://sandbox.cashfree.com/pg'
    ],

    // ─── JSON Storage ─────────────────────────────────────────────────────────
    'data_dir' => __DIR__ . '/data',

];
