<?php
/**
 * /webhook.php — Server-to-server webhooks from Razorpay and Cashfree
 *
 * Razorpay Webhook URL:  https://pay.rudhvedinfotech.com/webhook.php?gateway=razorpay
 * Cashfree Webhook URL:  https://pay.rudhvedinfotech.com/webhook.php?gateway=cashfree
 *
 * Register these in your Razorpay & Cashfree dashboards.
 * Razorpay  → Settings → Webhooks → Add webhook URL
 * Cashfree  → Developers → Webhooks → Add endpoint
 */

require_once __DIR__ . '/lib/helpers.php';
require_once __DIR__ . '/lib/Razorpay.php';
require_once __DIR__ . '/lib/Cashfree.php';

header('Content-Type: application/json');

$gateway = strtolower(trim($_GET['gateway'] ?? ''));
$raw     = file_get_contents('php://input');
$payload = json_decode($raw, true);

if (!in_array($gateway, ['razorpay', 'cashfree'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid gateway']);
    exit;
}

// ── Razorpay Webhook ──────────────────────────────────────────────────────────
if ($gateway === 'razorpay') {
    $signature = $_SERVER['HTTP_X_RAZORPAY_SIGNATURE'] ?? '';

    $rp = new Razorpay($config['razorpay']['key_id'], $config['razorpay']['key_secret']);

    if (!$rp->verifyWebhook($raw, $signature)) {
        http_response_code(401);
        echo json_encode(['error' => 'Invalid webhook signature']);
        exit;
    }

    $event      = $payload['event'] ?? '';
    $payment    = $payload['payload']['payment']['entity'] ?? [];
    $order_id   = $payment['order_id'] ?? '';
    $payment_id = $payment['id'] ?? '';

    if (empty($order_id)) {
        http_response_code(200);
        echo json_encode(['ok' => true, 'note' => 'No order_id in payload']);
        exit;
    }

    // Find transaction by gateway_order_id
    $txns = txn_list();
    $txn  = null;
    foreach ($txns as $t) {
        if (($t['gateway_order_id'] ?? '') === $order_id) {
            $txn = $t;
            break;
        }
    }

    if (!$txn) {
        http_response_code(200);
        echo json_encode(['ok' => true, 'note' => 'Transaction not found for order: ' . $order_id]);
        exit;
    }

    // Already finalized — don't process again
    if (in_array($txn['status'], ['paid', 'failed'])) {
        http_response_code(200);
        echo json_encode(['ok' => true, 'note' => 'Already processed']);
        exit;
    }

    $new_status = match(true) {
        in_array($event, ['payment.captured', 'payment.authorized']) => 'paid',
        in_array($event, ['payment.failed'])                         => 'failed',
        default                                                       => null,
    };

    if ($new_status) {
        $update = [
            'status'           => $new_status,
            'gateway_txn_id'   => $payment_id,
            'gateway_response' => $payload,
        ];
        if ($new_status === 'paid') $update['paid_at'] = date('c');

        txn_update($txn['txn_id'], $update);
        $txn = array_merge($txn, $update);
        notify_webhook($txn);
    }

    http_response_code(200);
    echo json_encode(['ok' => true]);
    exit;
}

// ── Cashfree Webhook ──────────────────────────────────────────────────────────
if ($gateway === 'cashfree') {
    $timestamp = $_SERVER['HTTP_X_WEBHOOK_TIMESTAMP'] ?? '';
    $signature = $_SERVER['HTTP_X_WEBHOOK_SIGNATURE']  ?? '';

    $cf = new Cashfree($config['cashfree']['app_id'], $config['cashfree']['secret_key'], $config['cashfree']['base_url']);

    if ($timestamp && $signature) {
        if (!$cf->verifyWebhook($timestamp, $raw, $signature)) {
            http_response_code(401);
            echo json_encode(['error' => 'Invalid webhook signature']);
            exit;
        }
    }

    $event    = $payload['type'] ?? '';
    $data     = $payload['data'] ?? [];
    $order    = $data['order'] ?? [];
    $payment  = $data['payment'] ?? [];

    $cf_order_id = $order['order_id'] ?? '';
    $cf_payment_id = $payment['cf_payment_id'] ?? null;

    if (empty($cf_order_id)) {
        http_response_code(200);
        echo json_encode(['ok' => true, 'note' => 'No order_id in payload']);
        exit;
    }

    // Find transaction by txn_id (we set txn_id as CF order_id)
    $txn = txn_load($cf_order_id);

    if (!$txn) {
        http_response_code(200);
        echo json_encode(['ok' => true, 'note' => 'Transaction not found: ' . $cf_order_id]);
        exit;
    }

    if (in_array($txn['status'], ['paid', 'failed'])) {
        http_response_code(200);
        echo json_encode(['ok' => true, 'note' => 'Already processed']);
        exit;
    }

    $cf_status  = strtoupper($payment['payment_status'] ?? $order['order_status'] ?? '');
    $new_status = match(true) {
        in_array($cf_status, ['SUCCESS', 'PAID'])              => 'paid',
        in_array($cf_status, ['FAILED', 'CANCELLED', 'EXPIRED']) => 'failed',
        default                                                  => null,
    };

    if ($new_status) {
        $update = [
            'status'           => $new_status,
            'gateway_txn_id'   => $cf_payment_id,
            'gateway_response' => $payload,
        ];
        if ($new_status === 'paid') $update['paid_at'] = date('c');

        txn_update($txn['txn_id'], $update);
        $txn = array_merge($txn, $update);
        notify_webhook($txn);
    }

    http_response_code(200);
    echo json_encode(['ok' => true]);
    exit;
}
