<?php
/**
 * Hosted Payment Page
 * URL: /pay.php?txn=TXN_XXXXX
 * Customer is redirected here by vara567.com
 */

require_once __DIR__ . '/lib/helpers.php';

$txn_id = trim($_GET['txn'] ?? '');
if (empty($txn_id)) {
    http_response_code(400);
    die('Invalid payment link.');
}

$txn = txn_load($txn_id);
if (!$txn) {
    http_response_code(404);
    die('Payment link not found or expired.');
}

if ($txn['status'] === 'paid') {
    header('Location: ' . $txn['return_url'] . '?txn_id=' . $txn_id . '&status=paid&order_id=' . urlencode($txn['order_id']));
    exit;
}

if ($txn['status'] === 'failed') {
    header('Location: ' . $txn['return_url'] . '?txn_id=' . $txn_id . '&status=failed&order_id=' . urlencode($txn['order_id']));
    exit;
}

$gateway   = $txn['gateway'];
$amount    = $txn['amount'];
$currency  = $txn['currency'];
$pay_url   = $config['pay_url'];
$return_cb = $pay_url . '/return.php?txn=' . urlencode($txn_id);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Complete Your Payment — ₹<?= number_format($amount, 2) ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<?php if ($gateway === 'razorpay'): ?>
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<?php elseif ($gateway === 'cashfree'): ?>
<script src="https://sdk.cashfree.com/js/v3/cashfree.js"></script>
<?php endif; ?>
<style>
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  :root {
    --bg:         #0a0c10;
    --card:       #111318;
    --border:     #1e2330;
    --accent:     #4f6ef7;
    --accent2:    #7c3aed;
    --success:    #10b981;
    --warning:    #f59e0b;
    --danger:     #ef4444;
    --text:       #e2e8f0;
    --muted:      #64748b;
    --mono:       'JetBrains Mono', monospace;
    --sans:       'Sora', sans-serif;
  }

  body {
    font-family: var(--sans);
    background: var(--bg);
    color: var(--text);
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 20px;
    background-image:
      radial-gradient(ellipse 80% 50% at 50% -20%, rgba(79,110,247,0.15), transparent),
      radial-gradient(ellipse 50% 50% at 100% 80%, rgba(124,58,237,0.08), transparent);
  }

  .card {
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: 20px;
    width: 100%;
    max-width: 440px;
    overflow: hidden;
    box-shadow: 0 25px 60px rgba(0,0,0,0.5), 0 0 0 1px rgba(79,110,247,0.1);
  }

  .card-header {
    padding: 28px 32px 22px;
    border-bottom: 1px solid var(--border);
    background: linear-gradient(135deg, rgba(79,110,247,0.06), rgba(124,58,237,0.04));
  }

  .brand {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 20px;
  }

  .brand-icon {
    width: 36px;
    height: 36px;
    background: linear-gradient(135deg, var(--accent), var(--accent2));
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 16px;
  }

  .brand-name {
    font-size: 14px;
    font-weight: 600;
    color: var(--muted);
    letter-spacing: 0.05em;
    text-transform: uppercase;
  }

  .amount-display {
    font-family: var(--mono);
    font-size: 42px;
    font-weight: 500;
    color: #fff;
    letter-spacing: -1px;
  }

  .amount-display .currency {
    font-size: 22px;
    color: var(--muted);
    vertical-align: super;
    font-weight: 400;
  }

  .description {
    font-size: 13px;
    color: var(--muted);
    margin-top: 6px;
  }

  .card-body {
    padding: 24px 32px;
  }

  .info-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px 0;
    border-bottom: 1px solid var(--border);
    font-size: 13px;
  }

  .info-row:last-child { border-bottom: none; }

  .info-label { color: var(--muted); }

  .info-value {
    font-weight: 500;
    color: var(--text);
    font-family: var(--mono);
    font-size: 12px;
  }

  .gateway-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 3px 10px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 600;
    letter-spacing: 0.04em;
    text-transform: uppercase;
  }

  .gateway-badge.razorpay {
    background: rgba(22, 120, 255, 0.12);
    color: #4f9eff;
    border: 1px solid rgba(79,158,255,0.2);
  }

  .gateway-badge.cashfree {
    background: rgba(16, 185, 129, 0.12);
    color: #34d399;
    border: 1px solid rgba(52,211,153,0.2);
  }

  .status-badge {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 3px 10px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 600;
    background: rgba(245,158,11,0.12);
    color: var(--warning);
    border: 1px solid rgba(245,158,11,0.2);
  }

  .status-badge::before {
    content: '';
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: var(--warning);
    animation: pulse 1.5s infinite;
  }

  @keyframes pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.3; }
  }

  .card-footer {
    padding: 20px 32px 28px;
  }

  .pay-btn {
    width: 100%;
    padding: 15px;
    background: linear-gradient(135deg, var(--accent), var(--accent2));
    color: #fff;
    border: none;
    border-radius: 12px;
    font-family: var(--sans);
    font-size: 15px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.2s;
    position: relative;
    overflow: hidden;
  }

  .pay-btn:hover {
    transform: translateY(-1px);
    box-shadow: 0 8px 25px rgba(79,110,247,0.4);
  }

  .pay-btn:active { transform: translateY(0); }

  .pay-btn:disabled {
    opacity: 0.6;
    cursor: not-allowed;
    transform: none;
  }

  .pay-btn .spinner {
    display: none;
    width: 18px;
    height: 18px;
    border: 2px solid rgba(255,255,255,0.3);
    border-top-color: #fff;
    border-radius: 50%;
    animation: spin 0.7s linear infinite;
    margin: 0 auto;
  }

  @keyframes spin { to { transform: rotate(360deg); } }

  .pay-btn.loading .btn-text { display: none; }
  .pay-btn.loading .spinner  { display: block; }

  .secure-note {
    text-align: center;
    font-size: 11px;
    color: var(--muted);
    margin-top: 14px;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 5px;
  }

  .alert {
    padding: 12px 16px;
    border-radius: 10px;
    font-size: 13px;
    margin-bottom: 16px;
  }

  .alert-danger {
    background: rgba(239,68,68,0.1);
    border: 1px solid rgba(239,68,68,0.2);
    color: #fca5a5;
  }
</style>
</head>
<body>

<div class="card">
  <div class="card-header">
    <div class="brand">
      <div class="brand-icon">💳</div>
      <span class="brand-name">Secure Payment</span>
    </div>
    <div class="amount-display">
      <span class="currency"><?= $currency === 'INR' ? '₹' : $currency ?></span><?= number_format($amount, 2) ?>
    </div>
    <div class="description"><?= htmlspecialchars($txn['description']) ?></div>
  </div>

  <div class="card-body">
    <div id="error-box" class="alert alert-danger" style="display:none;"></div>

    <div class="info-row">
      <span class="info-label">Order ID</span>
      <span class="info-value"><?= htmlspecialchars($txn['order_id']) ?></span>
    </div>
    <div class="info-row">
      <span class="info-label">Customer</span>
      <span class="info-value"><?= htmlspecialchars($txn['customer_name']) ?></span>
    </div>
    <div class="info-row">
      <span class="info-label">Gateway</span>
      <span class="gateway-badge <?= $gateway ?>"><?= ucfirst($gateway) ?></span>
    </div>
    <div class="info-row">
      <span class="info-label">Status</span>
      <span class="status-badge">Awaiting Payment</span>
    </div>
  </div>

  <div class="card-footer">
    <button class="pay-btn" id="payBtn" onclick="initiatePayment()">
      <span class="btn-text">Pay ₹<?= number_format($amount, 2) ?></span>
      <span class="spinner"></span>
    </button>
    <div class="secure-note">
      🔒 256-bit SSL Encrypted · Powered by <?= ucfirst($gateway) ?>
    </div>
  </div>
</div>

<script>
const TXN_ID = <?= json_encode($txn_id) ?>;
const GATEWAY = <?= json_encode($gateway) ?>;
const RETURN_CB = <?= json_encode($return_cb) ?>;
<?php if ($gateway === 'razorpay'): ?>
const RZP_KEY = <?= json_encode($config['razorpay']['key_id']) ?>;
const RZP_ORDER_ID = <?= json_encode($txn['gateway_order_id']) ?>;
const RZP_AMOUNT = <?= (int)($amount * 100) ?>;
const CUSTOMER_NAME  = <?= json_encode($txn['customer_name']) ?>;
const CUSTOMER_EMAIL = <?= json_encode($txn['customer_email']) ?>;
const CUSTOMER_PHONE = <?= json_encode($txn['customer_phone']) ?>;
<?php elseif ($gateway === 'cashfree'): ?>
const CF_SESSION_ID = <?= json_encode($txn['cf_payment_session_id'] ?? '') ?>;
const CF_PAYMENT_LINK = <?= json_encode($txn['cf_payment_link'] ?? '') ?>;
<?php endif; ?>

function showError(msg) {
  const el = document.getElementById('error-box');
  el.textContent = msg;
  el.style.display = 'block';
}

function setLoading(val) {
  const btn = document.getElementById('payBtn');
  btn.disabled = val;
  btn.classList.toggle('loading', val);
}

function initiatePayment() {
  setLoading(true);

  <?php if ($gateway === 'razorpay'): ?>
  const options = {
    key:         RZP_KEY,
    amount:      RZP_AMOUNT,
    currency:    <?= json_encode($currency) ?>,
    order_id:    RZP_ORDER_ID,
    name:        'vara567.com',
    description: <?= json_encode($txn['description']) ?>,
    prefill: {
      name:    CUSTOMER_NAME,
      email:   CUSTOMER_EMAIL,
      contact: CUSTOMER_PHONE,
    },
    theme: { color: '#4f6ef7' },
    handler: function(resp) {
      // Payment successful — POST to return handler
      const form = document.createElement('form');
      form.method = 'POST';
      form.action = RETURN_CB;
      const fields = {
        razorpay_payment_id:   resp.razorpay_payment_id,
        razorpay_order_id:     resp.razorpay_order_id,
        razorpay_signature:    resp.razorpay_signature,
      };
      for (const [k, v] of Object.entries(fields)) {
        const inp = document.createElement('input');
        inp.type = 'hidden'; inp.name = k; inp.value = v;
        form.appendChild(inp);
      }
      document.body.appendChild(form);
      form.submit();
    },
    modal: {
      ondismiss: function() { setLoading(false); }
    }
  };
  const rzp = new Razorpay(options);
  rzp.on('payment.failed', function(resp) {
    setLoading(false);
    showError('Payment failed: ' + (resp.error.description || 'Unknown error'));
  });
  rzp.open();

  <?php elseif ($gateway === 'cashfree'): ?>
  // Cashfree: redirect to hosted payment page
  if (CF_PAYMENT_LINK) {
    window.location.href = CF_PAYMENT_LINK;
  } else if (CF_SESSION_ID) {
    const cashfree = Cashfree({ mode: 'production' });
    cashfree.checkout({
      paymentSessionId: CF_SESSION_ID,
      redirectTarget: '_self',
    }).then(function(result) {
      if (result.error) {
        setLoading(false);
        showError(result.error.message || 'Payment failed');
      }
    });
  } else {
    setLoading(false);
    showError('Payment session not available. Please contact support.');
  }
  <?php endif; ?>
}
</script>
</body>
</html>
