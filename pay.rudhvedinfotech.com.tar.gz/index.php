<?php
session_start();
if (empty($_SESSION['dashboard_auth'])) {
    header('Location: login.php');
    exit;
}

require_once __DIR__ . '/lib/helpers.php';

$txns = txn_list();

// Summary stats
$total_txns    = count($txns);
$paid_txns     = array_filter($txns, fn($t) => $t['status'] === 'paid');
$pending_txns  = array_filter($txns, fn($t) => $t['status'] === 'pending');
$failed_txns   = array_filter($txns, fn($t) => $t['status'] === 'failed');
$total_revenue = array_sum(array_map(fn($t) => $t['amount'], $paid_txns));

// Gateway breakdown
$rp_paid = array_filter($paid_txns, fn($t) => $t['gateway'] === 'razorpay');
$cf_paid = array_filter($paid_txns, fn($t) => $t['gateway'] === 'cashfree');

// Logout
if ($_GET['logout'] ?? false) {
    session_destroy();
    header('Location: login.php');
    exit;
}

// View single transaction detail
$view_txn = null;
if (!empty($_GET['view'])) {
    $view_txn = txn_load($_GET['view']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Payment Dashboard — pay.rudhvedinfotech.com</title>
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --bg:#0a0c10;--sidebar:#0d0f14;--card:#111318;--card2:#14161c;
  --border:#1e2330;--border2:#252a38;
  --accent:#4f6ef7;--accent2:#7c3aed;
  --success:#10b981;--warning:#f59e0b;--danger:#ef4444;--info:#38bdf8;
  --text:#e2e8f0;--muted:#64748b;--muted2:#475569;
  --sans:'Sora',sans-serif;--mono:'JetBrains Mono',monospace;
}
body{font-family:var(--sans);background:var(--bg);color:var(--text);min-height:100vh;display:flex}
a{color:inherit;text-decoration:none}

/* ── Sidebar ── */
.sidebar{width:220px;min-height:100vh;background:var(--sidebar);border-right:1px solid var(--border);padding:24px 16px;display:flex;flex-direction:column;gap:4px;flex-shrink:0}
.sidebar-logo{display:flex;align-items:center;gap:10px;padding:0 8px 20px;margin-bottom:8px;border-bottom:1px solid var(--border)}
.sidebar-logo-icon{width:34px;height:34px;background:linear-gradient(135deg,var(--accent),var(--accent2));border-radius:9px;display:flex;align-items:center;justify-content:center;font-size:15px}
.sidebar-logo-text{font-size:13px;font-weight:600;line-height:1.2}
.sidebar-logo-sub{font-size:10px;color:var(--muted);font-family:var(--mono)}
.nav-item{display:flex;align-items:center;gap:10px;padding:9px 12px;border-radius:9px;font-size:13px;font-weight:500;color:var(--muted);cursor:pointer;transition:all .15s}
.nav-item:hover,.nav-item.active{background:var(--card);color:var(--text)}
.nav-item.active{color:var(--accent)}
.sidebar-footer{margin-top:auto;padding-top:16px;border-top:1px solid var(--border)}
.logout-btn{display:flex;align-items:center;gap:8px;padding:9px 12px;border-radius:9px;font-size:12px;color:var(--muted);cursor:pointer;transition:all .15s;text-decoration:none}
.logout-btn:hover{background:rgba(239,68,68,.1);color:#fca5a5}

/* ── Main ── */
.main{flex:1;overflow-x:hidden;padding:28px 32px}
.page-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:28px}
.page-title{font-size:22px;font-weight:700}
.page-sub{font-size:12px;color:var(--muted);margin-top:3px;font-family:var(--mono)}
.refresh-btn{padding:8px 16px;background:var(--card);border:1px solid var(--border);border-radius:9px;color:var(--muted);font-size:12px;font-family:var(--sans);cursor:pointer;transition:all .15s}
.refresh-btn:hover{color:var(--text);border-color:var(--border2)}

/* ── Stats Grid ── */
.stats-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin-bottom:28px}
.stat-card{background:var(--card);border:1px solid var(--border);border-radius:14px;padding:20px}
.stat-label{font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:.06em;margin-bottom:10px}
.stat-value{font-family:var(--mono);font-size:28px;font-weight:500;color:#fff;letter-spacing:-1px}
.stat-value.green{color:var(--success)}
.stat-value.amber{color:var(--warning)}
.stat-value.red{color:var(--danger)}
.stat-sub{font-size:11px;color:var(--muted);margin-top:6px}
.stat-icon{font-size:22px;margin-bottom:8px}

/* ── Gateway Pills ── */
.gw-row{display:flex;gap:12px;margin-bottom:28px}
.gw-pill{flex:1;background:var(--card);border:1px solid var(--border);border-radius:12px;padding:14px 18px;display:flex;align-items:center;justify-content:space-between}
.gw-name{font-size:12px;font-weight:600;color:var(--muted);text-transform:uppercase;letter-spacing:.05em}
.gw-amount{font-family:var(--mono);font-size:18px;font-weight:500}
.gw-count{font-size:11px;color:var(--muted);margin-top:2px}

/* ── Table ── */
.table-card{background:var(--card);border:1px solid var(--border);border-radius:14px;overflow:hidden}
.table-header{padding:16px 20px;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid var(--border)}
.table-title{font-size:14px;font-weight:600}
.search-box{padding:7px 12px;background:var(--bg);border:1px solid var(--border);border-radius:8px;color:var(--text);font-size:12px;font-family:var(--sans);outline:none;width:200px}
.search-box:focus{border-color:var(--accent)}
table{width:100%;border-collapse:collapse}
th{font-size:10px;text-transform:uppercase;letter-spacing:.07em;color:var(--muted);padding:10px 16px;border-bottom:1px solid var(--border);text-align:left;background:var(--card2);font-weight:500}
td{padding:13px 16px;border-bottom:1px solid var(--border);font-size:12px;vertical-align:middle}
tr:last-child td{border-bottom:none}
tr:hover td{background:rgba(255,255,255,.02);cursor:pointer}
.mono{font-family:var(--mono)}
.badge{display:inline-flex;align-items:center;gap:4px;padding:3px 9px;border-radius:20px;font-size:10px;font-weight:600;text-transform:uppercase;letter-spacing:.04em}
.badge.paid{background:rgba(16,185,129,.12);color:#34d399;border:1px solid rgba(52,211,153,.2)}
.badge.pending{background:rgba(245,158,11,.12);color:#fbbf24;border:1px solid rgba(251,191,36,.2)}
.badge.failed{background:rgba(239,68,68,.12);color:#fca5a5;border:1px solid rgba(252,165,165,.2)}
.badge.razorpay{background:rgba(22,120,255,.1);color:#60a5fa;border:1px solid rgba(96,165,250,.15)}
.badge.cashfree{background:rgba(16,185,129,.1);color:#34d399;border:1px solid rgba(52,211,153,.15)}
.badge.pending::before{content:'';width:5px;height:5px;border-radius:50%;background:#fbbf24;animation:pulse 1.5s infinite}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.3}}
.action-btn{padding:4px 10px;background:rgba(79,110,247,.1);border:1px solid rgba(79,110,247,.2);border-radius:6px;color:var(--accent);font-size:10px;font-family:var(--sans);cursor:pointer;transition:all .15s}
.action-btn:hover{background:rgba(79,110,247,.2)}
.empty-state{text-align:center;padding:60px 20px;color:var(--muted)}
.empty-icon{font-size:40px;margin-bottom:12px}
.empty-text{font-size:14px}

/* ── Modal ── */
.modal-overlay{position:fixed;inset:0;background:rgba(0,0,0,.7);z-index:100;display:flex;align-items:center;justify-content:center;padding:20px;backdrop-filter:blur(4px)}
.modal{background:var(--card);border:1px solid var(--border);border-radius:18px;width:100%;max-width:580px;max-height:80vh;overflow-y:auto}
.modal-head{padding:20px 24px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;background:var(--card);z-index:1}
.modal-title{font-size:15px;font-weight:600}
.modal-close{width:28px;height:28px;background:var(--bg);border:1px solid var(--border);border-radius:7px;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:14px;color:var(--muted)}
.modal-close:hover{color:var(--text)}
.modal-body{padding:20px 24px}
.detail-row{display:flex;gap:16px;padding:10px 0;border-bottom:1px solid var(--border);font-size:13px}
.detail-row:last-child{border-bottom:none}
.detail-key{color:var(--muted);width:160px;flex-shrink:0}
.detail-val{font-family:var(--mono);font-size:12px;word-break:break-all}
.json-block{background:var(--bg);border:1px solid var(--border);border-radius:8px;padding:12px;margin-top:12px;font-family:var(--mono);font-size:11px;white-space:pre-wrap;word-break:break-all;color:#94a3b8;max-height:200px;overflow-y:auto}
.section-title{font-size:11px;text-transform:uppercase;letter-spacing:.07em;color:var(--muted);margin:16px 0 8px}

@media(max-width:900px){.stats-grid{grid-template-columns:repeat(2,1fr)}.sidebar{display:none}.main{padding:20px 16px}}
</style>
</head>
<body>

<!-- ── Sidebar ──────────────────────────────────────────────────────────────── -->
<aside class="sidebar">
  <div class="sidebar-logo">
    <div class="sidebar-logo-icon">💳</div>
    <div>
      <div class="sidebar-logo-text">PayGate</div>
      <div class="sidebar-logo-sub">rudhvedinfotech</div>
    </div>
  </div>

  <a class="nav-item active">📊 Transactions</a>
  <a class="nav-item" href="api/initiate.php" style="pointer-events:none;opacity:.4">⚡ API Docs</a>

  <div class="sidebar-footer">
    <a href="?logout=1" class="logout-btn">← Logout</a>
  </div>
</aside>

<!-- ── Main ─────────────────────────────────────────────────────────────────── -->
<main class="main">
  <div class="page-header">
    <div>
      <div class="page-title">Payment Dashboard</div>
      <div class="page-sub">pay.rudhvedinfotech.com · <?= date('D, d M Y') ?></div>
    </div>
    <button class="refresh-btn" onclick="location.reload()">↻ Refresh</button>
  </div>

  <!-- Stats -->
  <div class="stats-grid">
    <div class="stat-card">
      <div class="stat-icon">💰</div>
      <div class="stat-label">Total Revenue</div>
      <div class="stat-value green">₹<?= number_format($total_revenue, 0) ?></div>
      <div class="stat-sub"><?= count($paid_txns) ?> successful payments</div>
    </div>
    <div class="stat-card">
      <div class="stat-icon">📦</div>
      <div class="stat-label">Total Transactions</div>
      <div class="stat-value"><?= $total_txns ?></div>
      <div class="stat-sub">All time</div>
    </div>
    <div class="stat-card">
      <div class="stat-icon">⏳</div>
      <div class="stat-label">Pending</div>
      <div class="stat-value amber"><?= count($pending_txns) ?></div>
      <div class="stat-sub">Awaiting payment</div>
    </div>
    <div class="stat-card">
      <div class="stat-icon">✗</div>
      <div class="stat-label">Failed</div>
      <div class="stat-value red"><?= count($failed_txns) ?></div>
      <div class="stat-sub">Declined / expired</div>
    </div>
  </div>

  <!-- Gateway Breakdown -->
  <div class="gw-row">
    <div class="gw-pill">
      <div>
        <div class="gw-name">🔵 Razorpay</div>
        <div class="gw-count"><?= count($rp_paid) ?> successful transactions</div>
      </div>
      <div class="gw-amount" style="color:#60a5fa">₹<?= number_format(array_sum(array_map(fn($t) => $t['amount'], $rp_paid)), 0) ?></div>
    </div>
    <div class="gw-pill">
      <div>
        <div class="gw-name">🟢 Cashfree</div>
        <div class="gw-count"><?= count($cf_paid) ?> successful transactions</div>
      </div>
      <div class="gw-amount" style="color:#34d399">₹<?= number_format(array_sum(array_map(fn($t) => $t['amount'], $cf_paid)), 0) ?></div>
    </div>
  </div>

  <!-- Transactions Table -->
  <div class="table-card">
    <div class="table-header">
      <div class="table-title">All Transactions</div>
      <input class="search-box" type="text" placeholder="Search order / customer..." id="searchInput" onkeyup="filterTable()">
    </div>

    <?php if (empty($txns)): ?>
    <div class="empty-state">
      <div class="empty-icon">🧾</div>
      <div class="empty-text">No transactions yet</div>
    </div>
    <?php else: ?>
    <table id="txnTable">
      <thead>
        <tr>
          <th>Txn ID</th>
          <th>Order ID</th>
          <th>Customer</th>
          <th>Amount</th>
          <th>Gateway</th>
          <th>Status</th>
          <th>Date</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($txns as $t): ?>
        <tr onclick="viewTxn('<?= htmlspecialchars($t['txn_id']) ?>')">
          <td class="mono" style="font-size:11px"><?= htmlspecialchars(substr($t['txn_id'], 0, 20)) ?>…</td>
          <td class="mono"><?= htmlspecialchars($t['order_id']) ?></td>
          <td>
            <div><?= htmlspecialchars($t['customer_name']) ?></div>
            <div style="font-size:10px;color:var(--muted)"><?= htmlspecialchars($t['customer_email']) ?></div>
          </td>
          <td class="mono" style="font-weight:500">₹<?= number_format($t['amount'], 2) ?></td>
          <td><span class="badge <?= $t['gateway'] ?>"><?= ucfirst($t['gateway']) ?></span></td>
          <td><span class="badge <?= $t['status'] ?>"><?= ucfirst($t['status']) ?></span></td>
          <td style="color:var(--muted);font-size:11px"><?= date('d M, H:i', strtotime($t['created_at'])) ?></td>
          <td><button class="action-btn" onclick="event.stopPropagation();viewTxn('<?= htmlspecialchars($t['txn_id']) ?>')">View</button></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <?php endif; ?>
  </div>
</main>

<!-- ── Transaction Detail Modal ─────────────────────────────────────────────── -->
<div class="modal-overlay" id="modal" style="display:none" onclick="closeModal(event)">
  <div class="modal" onclick="event.stopPropagation()">
    <div class="modal-head">
      <div class="modal-title">Transaction Detail</div>
      <button class="modal-close" onclick="closeModal()">✕</button>
    </div>
    <div class="modal-body" id="modalBody"></div>
  </div>
</div>

<script>
const allTxns = <?= json_encode($txns) ?>;

function filterTable() {
  const q = document.getElementById('searchInput').value.toLowerCase();
  document.querySelectorAll('#txnTable tbody tr').forEach(row => {
    row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
  });
}

function viewTxn(txn_id) {
  const t = allTxns.find(x => x.txn_id === txn_id);
  if (!t) return;

  const statusColor = {paid:'#34d399', pending:'#fbbf24', failed:'#fca5a5'}[t.status] || '#94a3b8';

  const rows = [
    ['Txn ID',        t.txn_id],
    ['Order ID',      t.order_id],
    ['Amount',        '₹' + parseFloat(t.amount).toFixed(2) + ' ' + t.currency],
    ['Status',        `<span class="badge ${t.status}">${t.status}</span>`],
    ['Gateway',       `<span class="badge ${t.gateway}">${t.gateway}</span>`],
    ['Gateway Order', t.gateway_order_id || '—'],
    ['Gateway Txn',   t.gateway_txn_id   || '—'],
    ['Customer',      t.customer_name],
    ['Email',         t.customer_email],
    ['Phone',         t.customer_phone],
    ['Description',   t.description],
    ['Created',       t.created_at],
    ['Paid At',       t.paid_at || '—'],
    ['Return URL',    `<a href="${t.return_url}" target="_blank" style="color:var(--accent)">${t.return_url}</a>`],
    ['Webhook URL',   `<a href="${t.webhook_url}" target="_blank" style="color:var(--accent)">${t.webhook_url}</a>`],
  ];

  let html = rows.map(([k, v]) =>
    `<div class="detail-row"><div class="detail-key">${k}</div><div class="detail-val">${v}</div></div>`
  ).join('');

  if (t.gateway_response) {
    html += `<div class="section-title">Gateway Response</div>`;
    html += `<div class="json-block">${JSON.stringify(t.gateway_response, null, 2)}</div>`;
  }

  document.getElementById('modalBody').innerHTML = html;
  document.getElementById('modal').style.display = 'flex';
}

function closeModal(e) {
  if (!e || e.target === document.getElementById('modal')) {
    document.getElementById('modal').style.display = 'none';
  }
}

document.addEventListener('keydown', e => { if (e.key === 'Escape') closeModal(); });
</script>
</body>
</html>
