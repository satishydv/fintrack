<?php
/**
 * Payment Gateway Aggregator - Configuration
 * Hosted at: https://deposit.rudhvedinfotech.com
 * Integrates with: https://vara567.com (Laravel)
 */

return [

    // ─── Shared secret between vara567.com and this project ───────────────────
    // Set the SAME key in vara567.com's .env as PAYMENT_API_KEY
    'api_key' => '12345678',

    // ─── Dashboard Login ──────────────────────────────────────────────────────
    'dashboard_password' => '12345678',

    // ─── This server's base URL ───────────────────────────────────────────────
    'pay_url' => 'https://deposit.yourdomain.com',  // ✅ IMPORTANT (YOUR DOMAIN)

    'timezone' => 'Asia/Kolkata',

    // ─── Razorpay (Live) ──────────────────────────────────────────────────────
    'razorpay' => [
        'key_id'     => 'your_razorpay_key_id',
        'key_secret' => 'your_razorpay_key_secret',
        'webhook_secret' => 'your_razorpay_webhook_secret',
    ],

    // ─── Cashfree (Production) ───────────────────────────────────────────────
    'cashfree' => [
        'app_id'     => 'your_cashfree_app_id',
        'secret_key' => 'your_cashfree_secret_key',
        'base_url'   => 'https://api.cashfree.com/pg',  // production
        // sandbox: 'https://sandbox.cashfree.com/pg'
    ],

    // ─── JSON Storage ─────────────────────────────────────────────────────────
    // PayU India (Production)
    'payu' => [
        'key'         => 'your_payu_key',
        'salt'        => 'your_payu_salt',
        'payment_url' => 'https://secure.payu.in/_payment',
        'verify_url'  => 'https://info.payu.in/merchant/postservice?form=2',
        // sandbox:
        // 'payment_url' => 'https://test.payu.in/_payment',
        // 'verify_url'  => 'https://test.payu.in/merchant/postservice?form=2',
    ],

    'data_dir' => __DIR__ . '/data',

];
